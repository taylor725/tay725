package Devoir.java;
public class Devoir {
    public static void main(String[] args) {
        double prixIphone = 285000;
        double taxe = 0.15 * prixIphone;
        double montantTotal = prixIphone + taxe;
        double economieParJour = 2500;
        int joursNecessaires = (int) Math.ceil(montantTotal / economieParJour);
        int joursOuvrablesParSemaine = 5;
        int semainesCompletes = joursNecessaires / joursOuvrablesParSemaine;
        int joursRestants = joursNecessaires % joursOuvrablesParSemaine;
        int totalJoursCalendaires = (semainesCompletes * 7) + joursRestants;
        // Affichage des résultats
        System.out.println("Le montant total à économiser est : " + montantTotal + " gourdes.");
        System.out.println("Nombre total de jours calendaires (incluant Samedi&Dimanche) : " + totalJoursCalendaires);
    }
}
