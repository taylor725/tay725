package Devoir_1;
public class Devoir {
    public static void main(String[] args) {
        double PI = 285000;
        double taxe = 0.15 * PI;
        double montantTotal =  + taxe;
        double economieParJour = 2500;
        int nombreDeJours = (int) Math.ceil(montantTotal / economieParJour);
        // Affichage du résultat
        System.out.println("Le montant total à économiser est : " + montantTotal + " gourdes.");
        System.out.println("Nombre de jours nécessaires pour économiser : " + nombreDeJours + " jours.");
    }
}
