package Music;

	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.Scanner;

	class Etudiant {
	    String nom;
	    String prenom;
	    HashMap<String, ArrayList<Double>> notesParFiliere;

	    public Etudiant(String nom, String prenom) {
	        this.nom = nom;
	        this.prenom = prenom;
	        this.notesParFiliere = new HashMap<>();
	    }

	    public void ajouterNotes(String filiere, ArrayList<Double> notes) {
	        this.notesParFiliere.put(filiere, notes);
	    }

	    public double calculerMoyenne(String filiere) {
	        if (notesParFiliere.containsKey(filiere)) {
	            ArrayList<Double> notes = notesParFiliere.get(filiere);
	            double somme = 0;
	            for (double note : notes) {
	                somme += note;
	            }
	            return somme / notes.size();
	        }
	        return 0.0;
	    }
	}

	public class GestionEtudiants {
	    static Scanner scanner = new Scanner(System.in);
	    static ArrayList<Etudiant> listeEtudiants = new ArrayList<>();

	    public static void saisirEtudiants(int nombreEtudiants) {
	        for (int i = 0; i < nombreEtudiants; i++) {
	            System.out.println("Saisir le nom de l'étudiant " + (i + 1) + " :");
	            String nom = scanner.nextLine();
	            System.out.println("Saisir le prénom de l'étudiant " + (i + 1) + " :");
	            String prenom = scanner.nextLine();

	            Etudiant etudiant = new Etudiant(nom, prenom);
	            listeEtudiants.add(etudiant);
	        }
	    }

	    public static void saisirNotes() {
	        for (Etudiant etudiant : listeEtudiants) {
	            System.out.println("Saisir les notes pour l'étudiant " + etudiant.nom + " " + etudiant.prenom);
	            System.out.println("Choisir une filière (Génie Civil, Génie Électrique, Informatique) :");
	            String filiere = scanner.nextLine();
	            ArrayList<Double> notes = new ArrayList<>();
	            System.out.println("Combien de notes voulez-vous entrer ?");
	            int nombreNotes = scanner.nextInt();

	            for (int j = 0; j < nombreNotes; j++) {
	                System.out.println("Saisir la note " + (j + 1) + " :");
	                double note = scanner.nextDouble();
	                notes.add(note);
	            }
	            scanner.nextLine(); // vider le buffer du scanner

	            etudiant.ajouterNotes(filiere, notes);
	        }
	    }

	    public static void afficherMoyennes() {
	        for (Etudiant etudiant : listeEtudiants) {
	            System.out.println("Moyennes pour l'étudiant " + etudiant.nom + " " + etudiant.prenom);
	            for (String filiere : etudiant.notesParFiliere.keySet()) {
	                double moyenne = etudiant.calculerMoyenne(filiere);
	                System.out.println("Filière : " + filiere + " - Moyenne : " + moyenne);
	            }
	        }
	    }

	    public static void main(String[] args) {
	        System.out.println("Combien d'étudiants voulez-vous enregistrer ?");
	        int nombreEtudiants = scanner.nextInt();
	        scanner.nextLine(); // vider le buffer du scanner

	        saisirEtudiants(nombreEtudiants);
	        saisirNotes();
	        afficherMoyennes();
	    }
	}

